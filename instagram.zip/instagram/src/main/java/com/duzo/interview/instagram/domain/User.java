package com.duzo.interview.instagram.domain;

import java.util.Random;
import java.util.Set;
import lombok.Data;

@Data
public class User {

    private Long id = Math.abs(new Random().nextLong());

    private String name;

    private String phone;

    //oneToMany
    private Set<Post> post;

    //oneToMany
    private Set<User> follower;

}
