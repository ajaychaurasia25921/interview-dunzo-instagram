package com.duzo.interview.instagram.domain;

import java.util.Random;
import java.util.Set;
import lombok.Data;

@Data
public class Post {
    private Long id = Math.abs(new Random().nextLong());
    private String post;
    private Long like;
    private Long numberOfComment;
    private Set<Comment> comment;
}
