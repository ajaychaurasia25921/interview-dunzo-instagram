package com.duzo.interview.instagram.service;

import com.duzo.interview.instagram.domain.Post;
import com.duzo.interview.instagram.domain.User;
import java.util.Set;

public interface IUserService {
    User onboard(User user);

    Set<User> getAllUser();

    User requestFollowing(Long id, Long followId);

    User requestUnFollowing(Long id, Long followId);

    User post(Long id, Post post);

    Set<Post> getPost(Long id);
}
