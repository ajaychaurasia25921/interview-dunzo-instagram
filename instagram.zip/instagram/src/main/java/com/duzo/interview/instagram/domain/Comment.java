package com.duzo.interview.instagram.domain;

import java.util.Random;
import lombok.Data;

@Data
public class Comment {

    private Long id = Math.abs(new Random().nextLong());

    private String comment;

}
