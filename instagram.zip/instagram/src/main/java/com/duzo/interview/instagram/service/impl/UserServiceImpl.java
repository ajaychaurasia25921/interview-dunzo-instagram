package com.duzo.interview.instagram.service.impl;

import com.duzo.interview.instagram.domain.Post;
import com.duzo.interview.instagram.domain.User;
import com.duzo.interview.instagram.service.IUserService;
import java.util.LinkedHashSet;
import java.util.Set;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

@Service
public class UserServiceImpl implements IUserService {

    static Set<User> userDataList = new LinkedHashSet<>();

    @Override
    public User onboard(final User user) {
        return userDataList.add(user) ? user : new User();
    }

    @Override
    public Set<User> getAllUser() {
        return userDataList;
    }

    @Override
    public User requestFollowing(final Long id, final Long followId) {
        var userRequested = userDataList.stream().filter(user -> user.getId().equals(followId)).findFirst().get();
        userDataList.remove(userRequested);
        var followList = userRequested.getFollower();
        followList = (ObjectUtils.isEmpty(followList)) ? new LinkedHashSet<>() : followList;
        followList.add(userDataList.stream().filter(usr -> usr.getId().equals(id)).findFirst().get());
        userRequested.setFollower(followList);
        return userDataList.add(userRequested) ? userRequested : new User();
    }

    @Override
    public User requestUnFollowing(final Long id, final Long followId) {
        var userRequested = userDataList.stream().filter(user -> user.getId().equals(followId)).findFirst().get();
        userDataList.remove(userRequested);
        var followList = userRequested.getFollower();
        followList = (ObjectUtils.isEmpty(followList)) ? new LinkedHashSet<User>() : followList;
        followList.remove(followList.stream().filter(user -> user.getId().equals(id)).findFirst().get());
        userRequested.setFollower(followList);
        return userDataList.add(userRequested) ? userRequested : new User();
    }

    @Override
    public User post(final Long id, final Post post) {
        var user = userDataList.stream().filter(usr -> usr.getId().equals(id)).findFirst().get();
        userDataList.remove(user);
        var postList = user.getPost();
        postList = (ObjectUtils.isEmpty(postList)) ? new LinkedHashSet<>() : postList;
        postList.add(post);
        user.setPost(postList);
        return userDataList.add(user) ? user : new User();
    }

    @Override
    public Set<Post> getPost(Long id) {
        // get post of following in desc order
        return null;
    }
}
