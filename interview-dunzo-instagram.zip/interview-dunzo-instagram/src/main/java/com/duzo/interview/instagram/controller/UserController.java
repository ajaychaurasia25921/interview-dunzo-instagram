package com.duzo.interview.instagram.controller;

import com.duzo.interview.instagram.domain.Post;
import com.duzo.interview.instagram.domain.User;
import com.duzo.interview.instagram.service.IUserService;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/user")
public class UserController {

    @Autowired
    private IUserService service;

    @PostMapping
    public User onboard(@RequestBody User user) {
        return service.onboard(user);
    }

    @GetMapping
    public Set<User> getAllUser() {
        return service.getAllUser();
    }

    @PatchMapping("/{id}/follow/{followId}")
    public User requestFollowing(@PathVariable Long id, @PathVariable Long followId) {
        return (id.equals(followId)) ? new User() : service.requestFollowing(id, followId);
    }

    @PatchMapping("/{id}/un-follow/{followId}")
    public User requestUnFollowing(@PathVariable Long id, @PathVariable Long followId) {
        return (id.equals(followId)) ? new User() : service.requestUnFollowing(id, followId);
    }

    @PostMapping("/{id}/post")
    public User post(@PathVariable Long id, @RequestBody Post post) {
        return service.post(id, post);
    }

    @GetMapping("/{id}/post")
    public Set<Post> getPost(@PathVariable Long id){
        return service.getPost(id);
    }

}
